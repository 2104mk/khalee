import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HttpClientModule } from '../../node_modules/@angular/common/http';
import { Route,RouterModule } from '../../node_modules/@angular/router';
import { ShippingdetailsComponent } from './shippingdetails/shippingdetails.component';
const routes:Route[]=[{path:"shippingdetails",component:ShippingdetailsComponent}];
@NgModule({
  declarations: [
    AppComponent,
    ShippingdetailsComponent
  ],
  imports: [
    BrowserModule,FormsModule,RouterModule.forRoot(routes),HttpClientModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
