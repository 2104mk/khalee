export interface Ishippingdetails{
    customerid:number
    mobileno:number;
    name:string;
    doornum:string;
    street:string;
    city:string;
    state:string;
    pincode:number;
}