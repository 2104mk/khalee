package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="ship")
public class User {
	@Id
	private int customerid;
	
    private String name;	
	private  String street;	
	private String doornum;
	private String city;
	private String state;
	private int pincode;
	private long mobileno;
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getDoornum() {
		return doornum;
	}
	public void setDoornum(String doornum) {
		this.doornum = doornum;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public long getMobileno() {
		return mobileno;
	}
	public void setMobileno(long mobileno) {
		this.mobileno = mobileno;
	}
	@Override
	public String toString() {
		return "User [customerid=" + customerid + ", name=" + name + ", street=" + street + ", doornum=" + doornum
				+ ", city=" + city + ", state=" + state + ", pincode=" + pincode + ", mobileno=" + mobileno + "]";
	}
	public User(int customerid, String name, String street, String doornum, String city, String state, int pincode,
			long mobileno) {
		super();
		this.customerid = customerid;
		this.name = name;
		this.street = street;
		this.doornum = doornum;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.mobileno = mobileno;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	    
}
